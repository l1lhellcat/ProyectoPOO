package copamundial;

import copamundial.vista.VentanaPrincipal;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/**
 * Punto de entrada del Sistema de Gestion y Simulacion "Copa Mundial Java".
 * Modulo 1: Administracion y Parametros Iniciales.
 */
public class Main {

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ex) {
            // Si el Look and Feel del sistema no esta disponible, se usa el por defecto.
        }

        SwingUtilities.invokeLater(() -> {
            VentanaPrincipal ventana = new VentanaPrincipal();
            ventana.setVisible(true);
        });
    }
}
