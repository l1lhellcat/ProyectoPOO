package copamundial.vista;

import copamundial.datos.GestorDatos;
import javax.swing.JFrame;
import javax.swing.JTabbedPane;
import javax.swing.WindowConstants;

/**
 * Ventana principal del Modulo 1: Administracion y Parametros Iniciales
 * del Sistema de Gestion y Simulacion "Copa Mundial Java".
 */
public class VentanaPrincipal extends JFrame {

    private final GestorDatos gestor;

    private PanelConfiguracion panelConfiguracion;
    private PanelPaises panelPaises;
    private PanelEstadios panelEstadios;
    private PanelArbitros panelArbitros;

    public VentanaPrincipal() {
        super("Copa Mundial Java - Modulo 1: Administracion y Parametros Iniciales");
        this.gestor = new GestorDatos();
        construirInterfaz();
    }

    private void construirInterfaz() {
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(950, 650);
        setLocationRelativeTo(null);

        JTabbedPane pestanas = new JTabbedPane();

        panelConfiguracion = new PanelConfiguracion(this, gestor);
        panelPaises = new PanelPaises(this, gestor);
        panelEstadios = new PanelEstadios(this, gestor);
        panelArbitros = new PanelArbitros(this, gestor);

        pestanas.addTab("1. Configuracion", panelConfiguracion);
        pestanas.addTab("2. Paises", panelPaises);
        pestanas.addTab("3. Sedes / Estadios", panelEstadios);
        pestanas.addTab("4. Cuerpo Arbitral", panelArbitros);

        add(pestanas);
    }

    /**
     * Refresca las tres tablas dependientes despues de dimensionar el
     * torneo o de ejecutar la carga masiva de datos de demostracion.
     */
    public void actualizarTodo() {
        panelPaises.refrescar();
        panelEstadios.refrescar();
        panelArbitros.refrescar();
    }
}
